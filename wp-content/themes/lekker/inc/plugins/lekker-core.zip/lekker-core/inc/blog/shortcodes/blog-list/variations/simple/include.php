<?php

include_once LEKKER_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/simple/simple.php';