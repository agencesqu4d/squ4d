<?php

include_once LEKKER_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/side-area-cart.php';