<?php

include_once LEKKER_CORE_INC_PATH . '/content/helper.php';