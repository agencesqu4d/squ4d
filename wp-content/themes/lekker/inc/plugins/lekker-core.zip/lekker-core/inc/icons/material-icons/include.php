<?php

include_once LEKKER_CORE_INC_PATH . '/icons/material-icons/material-icons.php';