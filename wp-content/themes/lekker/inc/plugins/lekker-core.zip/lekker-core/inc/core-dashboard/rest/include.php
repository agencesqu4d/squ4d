<?php

include_once LEKKER_CORE_INC_PATH . '/core-dashboard/rest/rest.php';