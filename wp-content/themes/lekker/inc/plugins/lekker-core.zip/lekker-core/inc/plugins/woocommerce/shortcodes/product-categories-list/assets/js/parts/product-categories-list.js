(function ($) {
    "use strict";
	qodefCore.shortcodes.lekker_core_product_categories_list = {};
	qodefCore.shortcodes.lekker_core_product_categories_list.qodefMasonryLayout = qodef.qodefMasonryLayout;

})(jQuery);