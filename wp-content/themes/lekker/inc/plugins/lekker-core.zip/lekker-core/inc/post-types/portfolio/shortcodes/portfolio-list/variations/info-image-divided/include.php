<?php

include_once LEKKER_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/variations/info-image-divided/info-image-divided.php';