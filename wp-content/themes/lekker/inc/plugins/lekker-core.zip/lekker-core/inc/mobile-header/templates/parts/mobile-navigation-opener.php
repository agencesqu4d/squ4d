<a class="qodef-mobile-header-opener" href="#">
	<span class="qodef-m-lines">
		<span class="qodef-m-line qodef--1"></span>
		<span class="qodef-m-line qodef--2"></span>
	</span>
</a>