<?php

include_once LEKKER_CORE_PLUGINS_PATH . '/woocommerce/woocommerce.php';