<?php

include_once LEKKER_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/instagram-list.php';