<?php

include_once LEKKER_CORE_INC_PATH . '/icons/simple-line-icons/simple-line-icons.php';