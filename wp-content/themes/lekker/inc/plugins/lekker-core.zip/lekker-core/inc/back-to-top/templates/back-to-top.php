<a id="qodef-back-to-top" href="#">
    <span class="qodef-btn-background">
		<span class="qodef-m-nav-lines"></span>
		<span class="qodef-back-to-top-text">
			<?php esc_html_e( 'Back To Top', 'lekker-core' ); ?>
		</span>
    </span>
</a>