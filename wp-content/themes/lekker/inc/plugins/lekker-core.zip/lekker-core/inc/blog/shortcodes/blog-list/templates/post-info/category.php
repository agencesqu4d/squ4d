<div class="qodef-e-info-item qodef-e-info-category">
	<?php the_category( ', ' ); ?>
</div>