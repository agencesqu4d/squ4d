<?php

include_once LEKKER_CORE_INC_PATH . '/icons/elegant-icons/elegant-icons.php';