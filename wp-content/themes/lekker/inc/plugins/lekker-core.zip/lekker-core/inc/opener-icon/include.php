<?php

include_once LEKKER_CORE_INC_PATH . '/opener-icon/helper.php';