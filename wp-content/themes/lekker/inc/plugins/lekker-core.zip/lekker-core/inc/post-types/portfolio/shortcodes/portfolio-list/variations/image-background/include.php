<?php

include_once LEKKER_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/variations/image-background/image-background.php';