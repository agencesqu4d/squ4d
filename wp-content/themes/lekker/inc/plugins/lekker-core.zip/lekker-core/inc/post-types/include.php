<?php

include_once LEKKER_CORE_CPT_PATH . '/post-types.php';