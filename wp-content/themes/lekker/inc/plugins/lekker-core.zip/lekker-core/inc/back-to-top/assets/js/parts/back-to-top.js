(function ($) {
    "use strict";

    $(document).ready(function () {
        qodefBackToTop.init();
    });

    var qodefBackToTop = {
        init: function () {
            this.holder = $('#qodef-back-to-top');

            if (this.holder.length) {
                // Scroll To Top
                this.holder.on('click', function (e) {
                    e.preventDefault();
                    qodefBackToTop.animateScrollToTop();
                });

                qodefBackToTop.showHideBackToTop();
            }
        },
        animateScrollToTop: function () {
            var startPos = qodef.scroll,
                newPos = qodef.scroll,
                step = .85,
                animationFrameId;

            var startAnimation = function () {
                if (newPos === 0) return;
                newPos < 0.0001 ? newPos = 0 : null;
                var ease = qodefBackToTop.easingFunction((startPos - newPos) / startPos);
                qodef.htmlAndBody.scrollTop(startPos - (startPos - newPos) * ease);
                newPos = newPos * step;

                animationFrameId = requestAnimationFrame(startAnimation)
            }
            startAnimation();
            qodef.htmlAndBody.one('wheel touchstart', function () {
                cancelAnimationFrame(animationFrameId);
            });
        },
        easingFunction: function (n) {
            return 0 == n ? 0 : Math.pow(1024, n - 1);
        },
        showHideBackToTop: function () {
            $(window).scroll(function () {
                var $thisItem = $(this),
                    content = $('#qodef-page-wrapper').height(),
                    b = $thisItem.scrollTop(),
                    contentSpace = content - 820,
                    c = $thisItem.height(),
                    d;

                if (b > 0) {
                    d = b + c / 2;
                } else {
                    d = 1;
                }

                if (d < 1e3) {
                    qodefBackToTop.addClass('off');
                } else {
                    qodefBackToTop.addClass('on');
                }
                if (d > contentSpace) {
                    qodefBackToTop.changeColor('down');
                } else {
                    qodefBackToTop.changeColor('up');
                }
            });
        },
        addClass: function (a) {
            this.holder.removeClass('qodef--off qodef--on');

            if (a === 'on') {
                this.holder.addClass('qodef--on');
            } else {
                this.holder.addClass('qodef--off');
            }
        },
        changeColor: function (a) {
            var b = $("#qodef-back-to-top .qodef-btn-background");
            b.removeClass('up down');
            if (a === 'up') {
                b.addClass('up');
            } else {
                b.addClass('down');
            }
        }
    };

})(jQuery);
