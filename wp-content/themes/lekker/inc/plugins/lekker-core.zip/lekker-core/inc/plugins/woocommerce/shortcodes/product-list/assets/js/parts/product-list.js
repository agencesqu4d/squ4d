(function ($) {
	
    "use strict";
	qodefCore.shortcodes.lekker_core_product_list = {};
	qodefCore.shortcodes.lekker_core_product_list.qodefPagination = qodef.qodefPagination;
	qodefCore.shortcodes.lekker_core_product_list.qodefFilter = qodef.qodefFilter;
	qodefCore.shortcodes.lekker_core_product_list.qodefJustifiedGallery = qodef.qodefJustifiedGallery;
	qodefCore.shortcodes.lekker_core_product_list.qodefMasonryLayout = qodef.qodefMasonryLayout;

})(jQuery);