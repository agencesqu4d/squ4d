<?php

require_once QODE_FRAMEWORK_INC_PATH . '/widgets/class-qodeframeworkwidgets.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/class-qodeframeworkwidget.php';

require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgettype.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgetcolor.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgetselect.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgettext.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgettextarea.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgeticonpack.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgeticon.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/class-qodeframeworkfieldwidgetimage.php';
